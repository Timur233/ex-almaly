<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/building_steps.twig */
class __TwigTemplate_2b6f8443fc31f72ce26fc32d5020b89425ca2604a8f1f7b76034a4c952e56877 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        if ((array_key_exists("building_steps", $context) &&  !twig_test_empty(($context["building_steps"] ?? null)))) {
            // line 2
            echo "    <section id=\"building-steps\" class=\"building-steps section\">
        <div class=\"container\">

            <div class=\"flex\">
                <div class=\"flex__3 building-steps__title-block\">
                    <div class=\"section-title building-steps__title\">
                        <h2 class=\"section-title__h2\">
                            <strong>
                                ХОД
                                <br>
                                &nbsp;&nbsp;
                                СТРОИТЕЛЬСТВА
                            </strong>
                        </h2>
                        <span class=\"building-steps__author-label author-label\">
                            Дома Вашей Мечты
                        </span>
                    </div>
                </div>

                <div class=\"flex__9\">
                    <div class=\"building-steps__swiper swiper-container\">
                        <div class=\"swiper-wrapper\">
                            ";
            // line 25
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["building_steps"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 26
                echo "                                <div 
                                    class=\"swiper-slide building-steps__slide\" 
                                    style=\"background-image: url('https://cms.abpx.kz";
                // line 28
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["item"], "preview", [], "any", false, false, false, 28), "html", null, true);
                echo "')\"
                                >
                                    ";
                // line 30
                if (twig_get_attribute($this->env, $this->source, $context["item"], "gallery", [], "any", false, false, false, 30)) {
                    // line 31
                    echo "                                        <a 
                                            class=\"building-steps__link\" 
                                            href=\"#\" 
                                            data-gallery-images=\"";
                    // line 34
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["item"], "gallery", [], "any", false, false, false, 34));
                    $context['loop'] = [
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    ];
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["img"]) {
                        echo "https://cms.abpx.kz";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (($__internal_compile_0 = twig_get_attribute($this->env, $this->source, $context["img"], "styles", [], "any", false, false, false, 34)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0[0] ?? null) : null), "path", [], "any", false, false, false, 34), "html", null, true);
                        if ((twig_get_attribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 34) == false)) {
                            echo ",";
                        }
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['length'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['img'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    echo "\"  
                                            onclick=\"() => {frontend.lightBox(this.getAttribute('data-gallery-images')); return false}\">
                                            <div class=\"step-information\">
                                                <img src=\"assets/img/icons/360.svg\" class=\"step-information__icon\">
                                                <h3 class=\"step-information__title\">";
                    // line 38
                    echo twig_escape_filter($this->env, (($__internal_compile_1 = ($context["translate"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1[twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "format_date", [], "any", false, false, false, 38), "month", [], "any", false, false, false, 38)] ?? null) : null), "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["item"], "format_date", [], "any", false, false, false, 38), "year", [], "any", false, false, false, 38), "html", null, true);
                    echo "</h3>
                                            </div>
                                        </a>
                                    ";
                }
                // line 42
                echo "                                </div>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 44
            echo "                        </div>
                        
                        <div class=\"building-steps__controll building-steps__controll--left\">
                            <img src=\"assets/img/icons/arrow.svg\">
                        </div>
                        <div class=\"building-steps__controll building-steps__controll--right\">
                            <img src=\"assets/img/icons/arrow.svg\">
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class=\"lines\">
            <div class=\"lines__wrapper container\">
                <span class=\"lines__line lines__line--black lines__line--1\"></span>
                <span class=\"lines__line lines__line--black lines__line--2\"></span>
                <span class=\"lines__line lines__line--black lines__line--3\"></span>
                <span class=\"lines__line lines__line--black lines__line--2\"></span>
                <span class=\"lines__line lines__line--black lines__line--1\"></span>
            </div>
        </div>

    </section>
";
        }
    }

    public function getTemplateName()
    {
        return "widgets/building_steps.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  139 => 44,  132 => 42,  123 => 38,  84 => 34,  79 => 31,  77 => 30,  72 => 28,  68 => 26,  64 => 25,  39 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/building_steps.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-almaly/app/views/widgets/building_steps.twig");
    }
}
