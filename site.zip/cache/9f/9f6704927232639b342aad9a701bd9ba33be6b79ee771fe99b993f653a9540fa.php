<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/slider.twig */
class __TwigTemplate_441041c46b336091de425aaedd8f935802b4e1214d81efc04da4d23404d1aadc extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"home\" class=\"main-slider\">
    
    <div class=\"main-slider__swiper swiper-container\">
        <div class=\"swiper-wrapper main-slider__wrapper\">
            <div 
                class=\"swiper-slide main-slider__slide\" 
                style=\"background-image: 
                    url('https://cms.abpx.kz/storage/uploads/2022/06/14/62a8861ed983eCam_006.jpg')\"
            >
                <div class=\"main-slider__shadow\"></div>
                <div class=\"main-slider__content\">
                    <div class=\"container\">
                        <div class=\"slider-content\">
                            <h1 class=\"slider-content__title animate__animated animate__fadeInUp\">
                                <strong>Элитные Таунхаусы</strong>
                                <br> в Алматы
                            </h1>
                            <div class=\"slider-content__body animate__animated animate__fadeInUp\">
                                <p class=\"slider-content__accent-text\">
                                    <img src=\"assets/img/map-marker-alt-svgrepo-com 1.svg\" alt=\"\">
                                    г. Алматы, ул. Керей-Жанибек хандар 103Б, 103/15
                                </p>
                                <p>
                                    Первоклассный проект девелоперской группы Exclusive Qurylys 
                                    при финансовой поддержке 
                                </p>
                            </div>
                            <a href=\"#locations\" class=\"btn btn--gradient slider-content__button animate__animated animate__fadeInUp\">
                                Квартиры
                            </a>
                        </div>
                    </div>
                </div>

                <span class=\"main-slider__author-label author-label\">
                    Exclusive Almaly
                </span>
            </div>
        </div>

        <div class=\"container\">
            <div class=\"main-slider__ex-link\">
                <a 
                    href=\"https://exin.kz/\"
                    target=\"_blank\"
                >
                    <img src=\"assets/img/ex-logo.svg\" alt=\"\">
                </a>
            </div>
        </div>

        <div class=\"main-slider__pagination\"></div>
    </div>

    <div class=\"lines\">
        <div class=\"lines__wrapper container\">
            <span class=\"lines__line lines__line--1\"></span>
            <span class=\"lines__line lines__line--2\"></span>
            <span class=\"lines__line lines__line--3\"></span>
            <span class=\"lines__line lines__line--2\"></span>
            <span class=\"lines__line lines__line--1\"></span>
        </div>
    </div>
    
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/slider.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/slider.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-almaly/app/views/widgets/slider.twig");
    }
}
