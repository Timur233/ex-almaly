<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/horisontal_callback.twig */
class __TwigTemplate_d22b0c14fd7880500f9b8f702dca5b9bc226f7b51b2de768a7f042d153527dd6 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"callback\" class=\"callback-h section\">
   <div class=\"container\">
      <div class=\"flex callback-h__flex\">
         <div class=\"flex__6\">
            <div class=\"section-title callback-h__title\">
               <h2 class=\"section-title__h2\">
                  ЗАКАЗАТЬ<br>
                  <strong>ЗВОНОК</strong>
               </h2>
           </div>
           <form class=\"callback-h__form\" action=\"#\">
               <div class=\"input-group callback-h__group\">
                  <label class=\"callback-h__label\" for=\"staticTopFormName\">";
        // line 13
        echo twig_escape_filter($this->env, (($__internal_compile_0 = ($context["translate"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["name"] ?? null) : null), "html", null, true);
        echo "</label>
                  <input 
                     type=\"text\" 
                     class=\"input-group__input\" 
                     id=\"staticTopFormName\" 
                     name=\"name\" 
                     fieldname=\"Имя\"
                  >
               </div>

               <div class=\"input-group callback-h__group\">
                  <label class=\"callback-h__label\" for=\"staticTopFormPhone\">";
        // line 24
        echo twig_escape_filter($this->env, (($__internal_compile_1 = ($context["translate"] ?? null)) && is_array($__internal_compile_1) || $__internal_compile_1 instanceof ArrayAccess ? ($__internal_compile_1["phone"] ?? null) : null), "html", null, true);
        echo "</label>
                  <input 
                     type=\"text\" 
                     class=\"input-group__input\" 
                     id=\"staticTopFormPhone\" 
                     name=\"phone\" 
                     fieldname=\"Телефон\" 
                     required=\"required\"
                  >
               </div>

               <div class=\"input-group callback-h__group\">
                  <button 
                     class=\"btn btn--black callback-h__btn\" 
                     onclick=\"frontend.form(this); return false\"
                  >
                     ";
        // line 40
        echo twig_escape_filter($this->env, (($__internal_compile_2 = ($context["translate"] ?? null)) && is_array($__internal_compile_2) || $__internal_compile_2 instanceof ArrayAccess ? ($__internal_compile_2["call_back_me"] ?? null) : null), "html", null, true);
        echo "
                  </button>
               </div>
           </form>
         </div>
      </div>
   </div>

   <div class=\"lines\">
       <div class=\"lines__wrapper container\">
           <span class=\"lines__line lines__line--black lines__line--1\"></span>
           <span class=\"lines__line lines__line--black lines__line--2\"></span>
           <span class=\"lines__line lines__line--black lines__line--3\"></span>
           <span class=\"lines__line lines__line--black lines__line--2\"></span>
           <span class=\"lines__line lines__line--black lines__line--1\"></span>
       </div>
   </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/horisontal_callback.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 40,  65 => 24,  51 => 13,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/horisontal_callback.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-almaly/app/views/widgets/horisontal_callback.twig");
    }
}
