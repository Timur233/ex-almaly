<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/comfort.twig */
class __TwigTemplate_5df36c519927966f569703e9d578648e9af704604b59789580b9e8d78cffdb89 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"comfort\" class=\"comfort section\">
    <div class=\"container\">
        <div class=\"section-title comfort__title\">
            <h2 class=\"section-title__h2\">
                <strong>уровень комфорта</strong>
            </h2>
        </div>

        <div class=\"comfort__swiper swiper-container\">
            <div class=\"swiper-wrapper comfort__wrapper\">
                <div 
                    class=\"swiper-slide comfort__slide\" 
                    style=\"background-image: 
                        url('https://cms.abpx.kz/storage/uploads/2022/06/17/62ac678323171Cam_015.jpg')\"
                >
                    <span class=\"comfort__author-label author-label animate__animated animate__fadeIn\">
                        Высокое Качество
                    </span>
                    <div style=\"display: none;\" class=\"animate__animated animate__fadeInUp comfort__body\">
                        <span class=\"comfort__item-sub-title\">ПРИРОДА</span>
                        <h3 class=\"comfort__item-title\">ПРОДАЖА КВАРТИР ПРЕМИУМ КЛАССА</h3>
                    </div>
                </div>
                <div 
                    class=\"swiper-slide comfort__slide\" 
                    style=\"background-image: 
                        url('https://cms.abpx.kz/storage/uploads/2022/06/17/62ac678323171Cam_015.jpg')\"
                >
                    <span class=\"comfort__author-label author-label animate__animated animate__fadeIn\">
                        Высокое Качество
                    </span>
                    <div style=\"display: none;\" class=\"animate__animated animate__fadeInUp comfort__body\">
                        <span class=\"comfort__item-sub-title\">ПРИРОДА</span>
                        <h3 class=\"comfort__item-title\">ПРОДАЖА КВАРТИР ПРЕМИУМ КЛАССА</h3>
                    </div>
                </div>
                <div 
                    class=\"swiper-slide comfort__slide\" 
                    style=\"background-image: 
                        url('https://cms.abpx.kz/storage/uploads/2022/06/17/62ac678323171Cam_015.jpg')\"
                >
                    <span class=\"comfort__author-label author-label animate__animated animate__fadeIn\">
                        Высокое Качество
                    </span>
                    <div style=\"display: none;\" class=\"animate__animated animate__fadeInUp comfort__body\">
                        <span class=\"comfort__item-sub-title\">ПРИРОДА</span>
                        <h3 class=\"comfort__item-title\">ПРОДАЖА КВАРТИР ПРЕМИУМ КЛАССА</h3>
                    </div>
                </div>
                <div 
                    class=\"swiper-slide comfort__slide\" 
                    style=\"background-image: 
                        url('https://cms.abpx.kz/storage/uploads/2022/06/17/62ac678323171Cam_015.jpg')\"
                >
                    <span class=\"comfort__author-label author-label animate__animated animate__fadeIn\">
                        Высокое Качество
                    </span>
                    <div style=\"display: none;\" class=\"animate__animated animate__fadeInUp comfort__body\">
                        <span class=\"comfort__item-sub-title\">ПРИРОДА</span>
                        <h3 class=\"comfort__item-title\">ПРОДАЖА КВАРТИР ПРЕМИУМ КЛАССА</h3>
                    </div>
                </div>
                <div 
                    class=\"swiper-slide comfort__slide\" 
                    style=\"background-image: 
                        url('https://cms.abpx.kz/storage/uploads/2022/06/17/62ac678323171Cam_015.jpg')\"
                >
                    <span class=\"comfort__author-label author-label animate__animated animate__fadeIn\">
                        Высокое Качество
                    </span>
                    <div style=\"display: none;\" class=\"animate__animated animate__fadeInUp comfort__body\">
                        <span class=\"comfort__item-sub-title\">ПРИРОДА</span>
                        <h3 class=\"comfort__item-title\">ПРОДАЖА КВАРТИР ПРЕМИУМ КЛАССА</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class=\"lines\">
        <div class=\"lines__wrapper container\">
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--3\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/comfort.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/comfort.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-almaly/app/views/widgets/comfort.twig");
    }
}
