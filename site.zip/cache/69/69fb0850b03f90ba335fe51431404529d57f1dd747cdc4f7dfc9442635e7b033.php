<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/advantages.twig */
class __TwigTemplate_69ce5dd797f73b626913f6ac1cfcf18e0845c217eea9eed4df7649ad12f7956d extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"advantages\" class=\"advantages section\">
    <div class=\"container\">
        <div class=\"advantages__swiper swiper-container\">
            <div class=\"swiper-wrapper advantages__wrapper\">
                <div 
                    class=\"swiper-slide advantages__slide\" 
                    style=\"background-image: 
                        url('https://cms.abpx.kz/storage/uploads/2022/06/17/62ac678323171Cam_015.jpg')\"
                >
                    <h3 class=\"advantages__title\">ПРОДАЖА КВАРТИР ПРЕМИУМ КЛАССА</h3>
                    <div class=\"advantages__body\">
                        <p>sdfsdfdsfds sdf sdfdsfdsf sdfdsfsdf s</p>
                    </div>
                </div>
                <div 
                    class=\"swiper-slide advantages__slide\" 
                    style=\"background-image: 
                        url('https://cms.abpx.kz/storage/uploads/2022/06/17/62ac67820393bCam_013_2.jpg')\"
                >
                    <h3 class=\"advantages__title\">ПРОДАЖА КВАРТИР ПРЕМИУМ КЛАССА</h3>
                    <div class=\"advantages__body\">
                        <p>sdfsdfdsfds sdf sdfdsfdsf sdfdsfsdf s</p>
                    </div>
                </div>
                <div 
                    class=\"swiper-slide advantages__slide\" 
                    style=\"background-image: 
                        url('https://cms.abpx.kz/storage/uploads/2022/06/17/62ac678282cd4Cam_013_final_a.jpg')\"
                >
                    <h3 class=\"advantages__title\">ПРОДАЖА КВАРТИР ПРЕМИУМ КЛАССА</h3>
                    <div class=\"advantages__body\">
                        <p>sdfsdfdsfds sdf sdfdsfdsf sdfdsfsdf s</p>
                    </div>
                </div>
                <div 
                    class=\"swiper-slide advantages__slide\" 
                    style=\"background-image: 
                        url('https://cms.abpx.kz/storage/uploads/2022/06/17/62ac67817e411Cam_010_final.jpg')\"
                >
                    <h3 class=\"advantages__title\">ПРОДАЖА КВАРТИР ПРЕМИУМ КЛАССА</h3>
                    <div class=\"advantages__body\">
                        <p>sdfsdfdsfds sdf sdfdsfdsf sdfdsfsdf s</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class=\"lines\">
        <div class=\"lines__wrapper container\">
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--3\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/advantages.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/advantages.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-almaly/app/views/widgets/advantages.twig");
    }
}
