<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/appartaments.twig */
class __TwigTemplate_a51e81722f2cda7ab4df16fc0e35efee98ca60d6e6f4f896f9bba915b6ae8812 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"appartaments\" class=\"appartaments section\">
    <div class=\"container\">
        <div class=\"appartaments__title-block\">
            <div class=\"section-title appartaments__title\">
                <h2 class=\"section-title__h2\">
                    <strong>Элитные Таунхаусы</strong>
                </h2>
            </div>
            <div class=\"appartaments__desc\">
                Это современный формат жизни в окружении природы в котором из 
                каждой квартиры открывается <b>живописный вид</b> на пышную зелень, 
                которая была сохранена при строительстве жилого комплекса на 
                территории бывшего санатория <b>“Алмалы” </b>
            </div>
        </div>
        <div class=\"appartaments__map\">
            ";
        // line 17
        echo twig_include($this->env, $context, "widgets/appartaments__polygons.twig");
        echo "
            
            <img 
                src=\"https://cms.abpx.kz/storage/uploads/2022/06/20/62b067f9f1f9dinterective-map__bg.png\" 
                class=\"appartaments__bg\"
                alt=\"\"
            >

            <img 
                src=\"https://cms.abpx.kz/storage/uploads/2022/06/20/62b0744a862e1appartaments__cloud.png\"
                class=\"appartaments__cloud appartaments__cloud--left wow animate__fadeInLeft\"
                data-wow-duration=\"2s\"
            >

            <img 
                src=\"https://cms.abpx.kz/storage/uploads/2022/06/20/62b0744a862e1appartaments__cloud.png\"
                class=\"appartaments__cloud appartaments__cloud--right wow animate__fadeInRight\"
                data-wow-duration=\"2.2s\"
            >

            <span class=\"appartaments__author-label author-label\">
                Премиум Жилье
            </span>
        </div>
    </div>

    <div class=\"lines\">
        <div class=\"lines__wrapper container\">
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--3\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/appartaments.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 17,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/appartaments.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-almaly/app/views/widgets/appartaments.twig");
    }
}
