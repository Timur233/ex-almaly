<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/about_project.twig */
class __TwigTemplate_97e8b2ba4314e9f02ec8ff31d7082464291e357c038708a58261052434cc5f45 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"about-project\" class=\"about-project section\">
    <div class=\"container\">
        <div class=\"flex about-project__flex-block\">
            <div class=\"flex__5 about-project__left\">
                <div class=\"section-title\">
                    <h2 class=\"section-title__h2\">
                        O проекте <br>
                        <strong>Exclusive Almaly</strong>
                    </h2>
                </div>
                <div class=\"about-project__desc\">
                    Это проект представляет новейший класс жилья Eco Luxury - 
                    сочетание экологического малоэтажного квартала, 
                    беспрецедентного уровня бузопасности, роскошных строительных материалов 
                    и инженерных систем.
                </div>
                <a href=\"#locations\" class=\"btn btn--black\">
                    Скачать брошюру
                </a>

                <span class=\"about-project__author-label author-label\">
                    Высокое Качество
                </span>

            </div>
            <div class=\"flex__7 about-project__right\">
                <div class=\"about-project__images\">
                    <img 
                        class=\"about-project__image-one wow animate__fadeInUp\"
                        data-wow-duration=\"1.5s\"
                        src=\"https://cms.abpx.kz/storage/uploads/2022/06/17/62ac166259316about_image.jpg\" 
                        alt=\"\"
                    >
                    <img 
                        class=\"about-project__image-two wow animate__fadeInUp\"
                        data-wow-duration=\"1.8s\"
                        src=\"https://cms.abpx.kz/storage/uploads/2022/06/17/62ac1661d42b5about_image_two.jpg\" 
                        alt=\"\"
                    >
                </div>
            </div>
        </div>
    </div>

    <div class=\"lines\">
        <div class=\"lines__wrapper container\">
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--3\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/about_project.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/about_project.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-almaly/app/views/widgets/about_project.twig");
    }
}
