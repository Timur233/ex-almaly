<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/_header.twig */
class __TwigTemplate_9c3e91833de1d2a4e662706ab64a384f271c2617e941c4641beb2b979fa1fb68 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<header class=\"main-header\">
   <div class=\"container\">
      <div class=\"main-header__content\">
         <div class=\"main-header__menu-toggle\">
            <div class=\"menu-toggle\">
               <span class=\"menu-toggle__line\"></span>
               <span class=\"menu-toggle__line\"></span>
               <span class=\"menu-toggle__line\"></span>
            </div>
         </div>

         <div class=\"navigate main-header__navigate\">
            <nav class=\"navigate__block\">
               <a href=\"#about-project\" class=\"navigate__link\">ПРЕИМУЩЕСТВА</a>
               <a href=\"#gallery\" class=\"navigate__link\">О ПРОЕКТЕ</a>
               <a href=\"#advantages\" class=\"navigate__link\">ПЛАНИРОВКИ</a>
            </nav>
         </div>

         <div class=\"logo-block main-header__logo\">
            <a href=\"\">
               <img src=\"assets/img/logo.svg\" class=\"logo-block__img\" alt=\"Exclusive Qurylys\">
               <img src=\"assets/img/logo--dark.svg\" class=\"logo-block__img--dark\" alt=\"Exclusive Qurylys\">
            </a>
         </div>

         <div class=\"navigate main-header__navigate\">
            <nav class=\"navigate__block\">
               <a href=\"#about-project\" class=\"navigate__link\">ГАЛЕРЕЯ</a>
               <a href=\"#gallery\" class=\"navigate__link\">ХОД СТРОИТЕЛЬСТВА</a>
               <a href=\"#advantages\" class=\"navigate__link\">КОНТАКТЫ</a>
            </nav>
         </div>
         
         <div class=\"main-contact main-header__contact\">
            <div class=\"main-contact__block\">
               <a href=\"tel:";
        // line 37
        echo twig_escape_filter($this->env, ($context["site_phone"] ?? null), "html", null, true);
        echo "\" onclick=\"\" class=\"main-contact__phone\">
                  +7 771 461 32 15
               </a>
               <a href=\"#\" data-modal=\"#callback-modal\" class=\"main-contact__callback-link\">
                  ";
        // line 41
        echo twig_escape_filter($this->env, (($__internal_compile_0 = ($context["translate"] ?? null)) && is_array($__internal_compile_0) || $__internal_compile_0 instanceof ArrayAccess ? ($__internal_compile_0["callback_title"] ?? null) : null), "html", null, true);
        echo "
               </a>
            </div>
         </div>
      </div>
   </div>
</header>";
    }

    public function getTemplateName()
    {
        return "widgets/_header.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 41,  75 => 37,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/_header.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-almaly/app/views/widgets/_header.twig");
    }
}
