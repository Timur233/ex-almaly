<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* widgets/park_almaly.twig */
class __TwigTemplate_53fa71e8eddf5dcbddb23b2693d353a120b46217b2c36f3ee4ea1e8d89dd3809 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<section id=\"park-almaly\" class=\"section park-almaly\">
    <div class=\"container\">
        <div class=\"flex park-almaly__flex\">
            <div class=\"flex__7 park-almaly__swiper-block\">
                <div class=\"park-almaly__swiper swiper-container\">
                    <div class=\"swiper-wrapper\">
                        <div 
                            class=\"swiper-slide park-almaly__slide\" 
                            style=\"background-image: url('assets/img/park-image.jpg')\"
                        >
                            <a 
                                class=\"park-almaly__link\" 
                                href=\"#\" 
                            >
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class=\"flex__5\">
                <div class=\"section-title\">
                    <h2 class=\"section-title__h2\">
                        <strong>ландшафтный</strong> парк <br>у дома
                    </h2>
                </div>
                <p>
                    Contrary to popular belief, Lorem Ipsum is not simply random text. 
                    It has roots in a piece of classical Latin literature from 45 BC, 
                    making it over 2000 years old. Richard McClintock, a 
                    Latin professor at Hampden-Sydney College in Virginia, 
                    looked up one of the more obscure Latin words, consectetur, 
                    from a Lorem Ipsum passage, and going through the cites of 
                    the word in classical literature, discovered the undoubtable source. 
                </p>
                <p>
                    Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of 
                    \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, 
                    written in 45 BC. This book is a treatise on the theory of ethics, 
                    very popular during the Renaissance. The first line of Lorem Ipsum, 
                    \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.
                </p>


                    
                <div class=\"park-almaly__controll park-almaly__controll--left\">
                    <img src=\"assets/img/icons/arrow.svg\">
                </div>
                <div class=\"park-almaly__controll park-almaly__controll--right\">
                    <img src=\"assets/img/icons/arrow.svg\">
                </div>
            </div>
        </div>
    </div>

    <div class=\"lines\">
        <div class=\"lines__wrapper container\">
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--3\"></span>
            <span class=\"lines__line lines__line--black lines__line--2\"></span>
            <span class=\"lines__line lines__line--black lines__line--1\"></span>
        </div>
    </div>
</section>";
    }

    public function getTemplateName()
    {
        return "widgets/park_almaly.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "widgets/park_almaly.twig", "/Applications/XAMPP/xamppfiles/htdocs/ex-almaly/app/views/widgets/park_almaly.twig");
    }
}
