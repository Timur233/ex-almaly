import gulpSass from 'gulp-sass';

export const plugins = () => ({
    gulpSass,
});
